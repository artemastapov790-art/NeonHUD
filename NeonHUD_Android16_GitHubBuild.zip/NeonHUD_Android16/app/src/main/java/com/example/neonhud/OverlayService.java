package com.example.neonhud;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    private static final String CHANNEL = "neon_hud_channel";
    private WindowManager windowManager;
    private View panel;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        Notification notification = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Neon HUD активен")
                .setContentText("Плавающая панель интерфейса")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build();
        startForeground(7, notification);
        showPanel();
    }

    private void showPanel() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(22, 16, 22, 16);
        box.setBackgroundColor(0xEE151526);

        TextView header = new TextView(this);
        header.setText("✦ NEON HUD  •  ⋮");
        header.setTextColor(Color.rgb(57, 245, 255));
        header.setTextSize(16);
        header.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        box.addView(header);

        addOption(box, "HUD: ВКЛ", Color.rgb(57, 245, 255));
        addOption(box, "Профиль: NEON", Color.rgb(205, 110, 255));
        addOption(box, "Прозрачность: 90%", Color.WHITE);

        TextView close = new TextView(this);
        close.setText("ЗАКРЫТЬ ПАНЕЛЬ");
        close.setTextColor(Color.rgb(255, 105, 150));
        close.setPadding(0, 18, 0, 4);
        close.setOnClickListener(v -> stopSelf());
        box.addView(close);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.END;
        params.x = 24;
        params.y = 180;

        box.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float touchX, touchY;

            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    startX = params.x;
                    startY = params.y;
                    touchX = event.getRawX();
                    touchY = event.getRawY();
                    return true;
                } else if (event.getAction() == MotionEvent.ACTION_MOVE) {
                    params.x = startX - (int) (event.getRawX() - touchX);
                    params.y = startY + (int) (event.getRawY() - touchY);
                    windowManager.updateViewLayout(box, params);
                    return true;
                }
                return false;
            }
        });

        panel = box;
        windowManager.addView(panel, params);
    }

    private void addOption(LinearLayout parent, String label, int color) {
        TextView item = new TextView(this);
        item.setText(label);
        item.setTextColor(color);
        item.setTextSize(14);
        item.setPadding(0, 12, 0, 12);
        parent.addView(item);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL, "Neon HUD", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    @Override
    public void onDestroy() {
        if (windowManager != null && panel != null) {
            windowManager.removeView(panel);
            panel = null;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
