package com.example.neonhud;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQUEST = 410;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(36, 48, 36, 36);
        page.setBackgroundColor(0xFF10101A);

        TextView title = new TextView(this);
        title.setText("NEON HUD");
        title.setTextColor(0xFF39F5FF);
        title.setTextSize(30);
        title.setLetterSpacing(0.12f);
        page.addView(title);

        TextView info = new TextView(this);
        info.setText("\nПлавающая панель с локальными настройками интерфейса. "
                + "Она не меняет игру и не даёт игрового преимущества.\n");
        info.setTextColor(0xFFE7E7F2);
        info.setTextSize(16);
        page.addView(info);

        Button start = new Button(this);
        start.setText("ВКЛЮЧИТЬ NEON HUD");
        start.setOnClickListener(v -> enableOverlay());
        page.addView(start);

        Button stop = new Button(this);
        stop.setText("ВЫКЛЮЧИТЬ HUD");
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));
        page.addView(stop);

        setContentView(page);
    }

    private void enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Intent permission = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())
            );
            startActivityForResult(permission, OVERLAY_REQUEST);
            return;
        }
        Intent service = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(service);
        } else {
            startService(service);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQUEST && Settings.canDrawOverlays(this)) {
            enableOverlay();
        }
    }
}
