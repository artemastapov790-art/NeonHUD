plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.neonhud"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.neonhud"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }
}
